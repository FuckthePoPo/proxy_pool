module.exports = {
  printWidth: 90,
}
