This directory contains a very simple Rust program to demonstrate
how to run gdbgui.

Run the shell script `compile_and_debug.sh` which will use Cargo
to build the program in debug mode and then launch `gdbgui` to
debug the program.
