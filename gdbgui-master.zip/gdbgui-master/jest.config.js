module.exports = {
    "verbose": true,
    "testMatch": [__dirname  + '/gdbgui/src/js/tests/**']
}
